#include <Arduino.h>

/****************************************
 ASCENSOR DE 3 PISOS
 Autor: Johan

 MODIFICAR SOLAMENTE LOS PINES
 SI CAMBIA EL CABLEADO
****************************************/


//==================================================
// BOTONES INTERNOS
//==================================================

const int BTN_INT_1 = 2;
const int BTN_INT_2 = 3;
const int BTN_INT_3 = 4;


//==================================================
// BOTONES EXTERNOS
//==================================================

const int BTN_EXT_1 = 5;
const int BTN_EXT_2 = 6;
const int BTN_EXT_3 = 7;


//==================================================
// SENSORES DE PISO
//==================================================

const int SENSOR_1 = 8;
const int SENSOR_2 = 9;
const int SENSOR_3 = 10;


//==================================================
// FINALES DE CARRERA
//==================================================

const int FIN_INF = 11;
const int FIN_SUP = 12;


//==================================================
// MOTOR (L298N)
//==================================================

const int MOTOR_SUBIR = A0;
const int MOTOR_BAJAR = A1;


//==================================================
// LEDS
//==================================================

const int LED_1 = A2;
const int LED_2 = A3;
const int LED_3 = A4;


//==================================================
// VARIABLES DEL SISTEMA
//==================================================

int pisoActual = 1;
int pisoDestino = 0;


//==================================================
// PROTOTIPOS DE FUNCIONES
//==================================================

void leerBotones();
void detectarPisoActual();
void moverAscensor();
void subir();
void bajar();
void detenerMotor();
void actualizarLEDs();


//==================================================
// SETUP
//==================================================

void setup()
{
    Serial.begin(9600);

    pinMode(BTN_INT_1, INPUT_PULLUP);
    pinMode(BTN_INT_2, INPUT_PULLUP);
    pinMode(BTN_INT_3, INPUT_PULLUP);

    pinMode(BTN_EXT_1, INPUT_PULLUP);
    pinMode(BTN_EXT_2, INPUT_PULLUP);
    pinMode(BTN_EXT_3, INPUT_PULLUP);

    pinMode(SENSOR_1, INPUT_PULLUP);
    pinMode(SENSOR_2, INPUT_PULLUP);
    pinMode(SENSOR_3, INPUT_PULLUP);

    pinMode(FIN_INF, INPUT_PULLUP);
    pinMode(FIN_SUP, INPUT_PULLUP);

    pinMode(MOTOR_SUBIR, OUTPUT);
    pinMode(MOTOR_BAJAR, OUTPUT);

    pinMode(LED_1, OUTPUT);
    pinMode(LED_2, OUTPUT);
    pinMode(LED_3, OUTPUT);

    detenerMotor();
}


//==================================================
// LOOP PRINCIPAL
//==================================================

void loop()
{
    detectarPisoActual();

    leerBotones();

    moverAscensor();

    actualizarLEDs();
}